# Arzun Elektronik - Frontend

Kurulum için:

```bash
npm install
npm run dev
```